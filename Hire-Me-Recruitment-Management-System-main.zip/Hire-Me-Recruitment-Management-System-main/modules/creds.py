user_pwd = "Hitesh@20"  # use your MySQL Password
